package edu.fhnw.fetching_api

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffold
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import edu.fhnw.fetching_api.ui.theme.Fetching_apiTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.coroutines.cancellation.CancellationException

// global stuff
lateinit var prefs: SharedPreferences
val favs = mutableStateListOf<JSONObject>() // saved places (json from geocoding api)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        prefs = getSharedPreferences("favs", MODE_PRIVATE)
        loadFavs()
        setContent {
            Fetching_apiTheme {
                App()
            }
        }
    }
}

fun loadFavs() {
    favs.clear()
    try {
        val a = JSONArray(prefs.getString("list", "[]"))
        for (i in 0 until a.length()) {
            favs.add(a.getJSONObject(i))
        }
    } catch (e: Exception) {
        Log.d("FAVS", "broke loading favs " + e)
    }
}

fun saveFavs() {
    val a = JSONArray()
    for (f in favs) a.put(f)
    prefs.edit().putString("list", a.toString()).apply()
    Log.d("FAVS", "saved " + favs.size)
}

fun isFav(lat: Double, lon: Double): Boolean {
    for (f in favs) {
        if (f.getDouble("latitude") == lat && f.getDouble("longitude") == lon) {
            return true
        }
    }
    return false
}

// does the http request, MUST be called on background thread or it crashes!!
fun getUrl(u: String): String {
    Log.d("API", "calling " + u)
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 10000
    c.readTimeout = 10000
    c.setRequestProperty("User-Agent", "OutdoorPlanner/1.0 (Android student project)")
    if (c.responseCode != 200) {
        c.disconnect()
        throw Exception("bad response " + c.responseCode)
    }
    val txt = c.inputStream.bufferedReader().readText()
    c.disconnect()
    return txt
}

// WMO codes from open-meteo docs
fun weatherName(c: Int): String {
    if (c == 0) return "Clear sky"
    else if (c == 1) return "Mainly clear"
    else if (c == 2) return "Partly cloudy"
    else if (c == 3) return "Overcast"
    else if (c == 45 || c == 48) return "Fog"
    else if (c == 51 || c == 53 || c == 55) return "Drizzle"
    else if (c == 56 || c == 57) return "Freezing drizzle"
    else if (c == 61 || c == 63 || c == 65) return "Rain"
    else if (c == 66 || c == 67) return "Freezing rain"
    else if (c == 71 || c == 73 || c == 75 || c == 77) return "Snow"
    else if (c == 80 || c == 81 || c == 82) return "Rain showers"
    else if (c == 85 || c == 86) return "Snow showers"
    else if (c == 95 || c == 96 || c == 99) return "Thunderstorm"
    return "Unknown"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Top(title: String, back: (() -> Unit)?, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = {
                if (back != null) {
                    TextButton(onClick = back) { Text("← Back") }
                }
            }
        )
    }) { pad -> content(pad) }
}

@Composable
fun App() {
    var tab by rememberSaveable { mutableStateOf(0) } // 0 = search, 1 = favs, 2 = about
    var openPlace by rememberSaveable { mutableStateOf("") } // "" means no forecast open
    var text by rememberSaveable { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<JSONArray?>(null) }
    var searched by remember { mutableStateOf(false) }
    var netErr by remember { mutableStateOf(false) }
    var lastSearch by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val kb = LocalSoftwareKeyboardController.current

    BackHandler(enabled = openPlace != "") { openPlace = "" }

    NavigationSuiteScaffold(navigationSuiteItems = {
        item(
            icon = { Icon(painterResource(R.drawable.ic_home), contentDescription = "Search") },
            label = { Text("Search") },
            selected = tab == 0,
            onClick = { tab = 0; openPlace = "" }
        )
        item(
            icon = { Icon(painterResource(R.drawable.ic_favorite), contentDescription = "Favorites") },
            label = { Text("Favorites") },
            selected = tab == 1,
            onClick = { tab = 1; openPlace = "" }
        )
        item(
            icon = { Icon(painterResource(R.drawable.ic_account_box), contentDescription = "About") },
            label = { Text("About") },
            selected = tab == 2,
            onClick = { tab = 2; openPlace = "" }
        )
    }) {
        if (openPlace != "") {
            Forecast(JSONObject(openPlace)) { openPlace = "" }
        } else if (tab == 0) {
            Top("Outdoor Planner", null) { pad ->
                Column(Modifier.padding(pad).padding(horizontal = 16.dp).fillMaxSize()) {
                    Text("Find the best day this week for a hike, run or ride.", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.Top) {
                        OutlinedTextField(
                            value = text,
                            onValueChange = { text = it; err = "" },
                            label = { Text("City name") },
                            placeholder = { Text("e.g. Denver") },
                            isError = err != "",
                            supportingText = { if (err != "") Text(err) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                // same as button below
                                kb?.hide()
                                val q = text.trim()
                                if (q == "") {
                                    err = "Please enter a city name."
                                } else if (q.length < 2) {
                                    err = "Enter at least 2 characters."
                                } else if (!Regex("^[\\p{L} .'-]+$").matches(q)) {
                                    err = "Use letters only, e.g. \"Denver\" or \"São Paulo\"."
                                } else {
                                    loading = true
                                    netErr = false
                                    results = null
                                    searched = true
                                    lastSearch = q
                                    scope.launch {
                                        try {
                                            val s = withContext(Dispatchers.IO) {
                                                getUrl("https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(q, "UTF-8") + "&count=10&language=en&format=json")
                                            }
                                            val j = JSONObject(s)
                                            if (j.has("results")) results = j.getJSONArray("results") else results = JSONArray()
                                        } catch (e: Exception) {
                                            Log.d("SEARCH", "failed " + e.message)
                                            netErr = true
                                        }
                                        loading = false
                                    }
                                }
                            }),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = {
                            kb?.hide()
                            val q = text.trim()
                            if (q == "") {
                                err = "Please enter a city name."
                            } else if (q.length < 2) {
                                err = "Enter at least 2 characters."
                            } else if (!Regex("^[\\p{L} .'-]+$").matches(q)) {
                                err = "Use letters only, e.g. \"Denver\" or \"São Paulo\"."
                            } else {
                                loading = true
                                netErr = false
                                results = null
                                searched = true
                                lastSearch = q
                                scope.launch {
                                    try {
                                        val s = withContext(Dispatchers.IO) {
                                            getUrl("https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(q, "UTF-8") + "&count=10&language=en&format=json")
                                        }
                                        val j = JSONObject(s)
                                        if (j.has("results")) results = j.getJSONArray("results") else results = JSONArray()
                                    } catch (e: Exception) {
                                        Log.d("SEARCH", "failed " + e.message)
                                        netErr = true
                                    }
                                    loading = false
                                }
                            }
                        }, enabled = !loading, modifier = Modifier.padding(top = 8.dp)) {
                            Text("Search")
                        }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        if (loading) {
                            CircularProgressIndicator(Modifier.align(Alignment.Center))
                        } else if (netErr) {
                            Text("Couldn't reach the weather service. Check your internet connection and try again.",
                                modifier = Modifier.align(Alignment.Center).padding(24.dp), textAlign = TextAlign.Center)
                        } else if (!searched) {
                            Text("Search for a city to see its 7-day outdoor forecast.",
                                modifier = Modifier.align(Alignment.Center).padding(24.dp), textAlign = TextAlign.Center)
                        } else if (results == null || results!!.length() == 0) {
                            Text("No places found for \"" + lastSearch + "\". Check the spelling and try again.",
                                modifier = Modifier.align(Alignment.Center).padding(24.dp), textAlign = TextAlign.Center)
                        } else {
                            val r = results!!
                            LazyColumn(Modifier.fillMaxSize()) {
                                items(r.length()) { i ->
                                    val p = r.getJSONObject(i)
                                    ListItem(
                                        headlineContent = { Text(p.getString("name")) },
                                        supportingContent = { Text(listOf(p.optString("admin1"), p.optString("country")).filter { it != "" }.joinToString(", ")) },
                                        modifier = Modifier.clickable { openPlace = p.toString() }
                                    )
                                    HorizontalDivider()
                                }
                            }
                        }
                    }
                    Text("Weather data by Open-Meteo.com (CC BY 4.0)", style = MaterialTheme.typography.labelSmall,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                }
            }
        } else if (tab == 1) {
            Top("Favorite places", null) { pad ->
                Column(Modifier.padding(pad).padding(horizontal = 16.dp).fillMaxSize()) {
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        if (favs.size == 0) {
                            Text("No favorites yet. Search for a city, open it, and tap \"Save to favorites\".",
                                modifier = Modifier.align(Alignment.Center).padding(24.dp), textAlign = TextAlign.Center)
                        } else {
                            LazyColumn(Modifier.fillMaxSize()) {
                                items(favs.size) { i ->
                                    val p = favs[i]
                                    ListItem(
                                        headlineContent = { Text(p.getString("name")) },
                                        supportingContent = { Text(listOf(p.optString("admin1"), p.optString("country")).filter { it != "" }.joinToString(", ")) },
                                        modifier = Modifier.clickable { openPlace = p.toString() }
                                    )
                                    HorizontalDivider()
                                }
                            }
                        }
                    }
                    Text("Weather data by Open-Meteo.com (CC BY 4.0)", style = MaterialTheme.typography.labelSmall,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                }
            }
        } else {
            Top("About", null) { pad ->
                Column(Modifier.padding(pad).padding(horizontal = 16.dp).fillMaxSize().verticalScroll(rememberScrollState())) {
                    Text("Outdoor Planner", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(12.dp))
                    Text("Who it's for: hikers, runners, cyclists and anyone planning time outside who wants a quick answer to \"which day this week is best?\" without reading a whole weather report.")
                    Spacer(Modifier.height(12.dp))
                    Text("How it works: search for a city and open it to see a 7 day forecast. A day counts as good for outdoors if there's no rain/snow/storm, rain chance is 30% or less, the high is between 10 and 30 °C and wind is 30 km/h or less. The best day gets a star.")
                    Spacer(Modifier.height(12.dp))
                    Text("Save places to Favorites to check them again later. Favorites are stored on this device.")
                    Spacer(Modifier.height(12.dp))
                    Text("Data source", style = MaterialTheme.typography.titleMedium)
                    Text("Weather forecasts and city search come from the Open-Meteo API (open-meteo.com), licensed under CC BY 4.0. No API key needed.")
                }
            }
        }
    }
}

@Composable
fun Forecast(p: JSONObject, back: () -> Unit) {
    val lat = p.getDouble("latitude")
    val lon = p.getDouble("longitude")
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var retry by remember { mutableStateOf(0) }
    var daily by remember { mutableStateOf<JSONObject?>(null) }
    var fav by remember { mutableStateOf(isFav(lat, lon)) }

    LaunchedEffect(lat, lon, retry) {
        loading = true
        error = false
        try {
            val s = withContext(Dispatchers.IO) {
                getUrl("https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max&timezone=auto&forecast_days=7")
            }
            daily = JSONObject(s).getJSONObject("daily")
            loading = false
        } catch (e: CancellationException) {
            throw e // user went back, this isnt a real error
        } catch (e: Exception) {
            Log.d("FORECAST", "error " + e)
            error = true
            loading = false
        }
    }

    Top(p.getString("name"), back) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp).fillMaxSize()) {
            Text(listOf(p.getString("name"), p.optString("admin1"), p.optString("country")).filter { it != "" }.joinToString(", "),
                style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            if (fav) {
                OutlinedButton(onClick = {
                    favs.removeAll { it.getDouble("latitude") == lat && it.getDouble("longitude") == lon }
                    saveFavs()
                    fav = false
                }, modifier = Modifier.fillMaxWidth()) { Text("★ Saved (tap to remove)") }
            } else {
                Button(onClick = {
                    favs.add(p)
                    saveFavs()
                    fav = true
                }, modifier = Modifier.fillMaxWidth()) { Text("☆ Save to favorites") }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (loading) {
                    CircularProgressIndicator(Modifier.align(Alignment.Center))
                } else if (error) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Couldn't load the forecast. Check your internet connection.", textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
                        Button(onClick = { retry++ }) { Text("Retry") }
                    }
                } else if (daily == null || daily!!.getJSONArray("time").length() == 0) {
                    Text("No forecast data available for this place.", modifier = Modifier.align(Alignment.Center).padding(24.dp), textAlign = TextAlign.Center)
                } else {
                    val d = daily!!
                    val t = d.getJSONArray("time")
                    val codes = d.getJSONArray("weather_code")
                    val hi = d.getJSONArray("temperature_2m_max")
                    val lo = d.getJSONArray("temperature_2m_min")
                    val rain = d.getJSONArray("precipitation_probability_max") // can have nulls in it!
                    val wind = d.getJSONArray("wind_speed_10m_max")
                    val fmt = DateTimeFormatter.ofPattern("EEE, MMM d")

                    // pick best day, lower score = better
                    var best = 0
                    var bestScore = 99999.0
                    for (i in 0 until t.length()) {
                        var r = 0
                        if (!rain.isNull(i)) r = rain.getInt(i)
                        var sc = r + wind.getDouble(i) + Math.abs(hi.getDouble(i) - 21) * 2
                        if (codes.getInt(i) >= 51) sc = sc + 50
                        if (sc < bestScore) {
                            bestScore = sc
                            best = i
                        }
                    }
                    fun good(i: Int): Boolean {
                        var r = 0
                        if (!rain.isNull(i)) r = rain.getInt(i)
                        return codes.getInt(i) < 51 && r <= 30 && hi.getDouble(i) >= 10 && hi.getDouble(i) <= 30 && wind.getDouble(i) <= 30
                    }

                    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
                        item {
                            if (good(best)) {
                                Text("Best day for outdoors: " + LocalDate.parse(t.getString(best)).format(fmt), style = MaterialTheme.typography.titleMedium)
                            } else {
                                Text("No great outdoor days this week. Least bad: " + LocalDate.parse(t.getString(best)).format(fmt), style = MaterialTheme.typography.titleMedium)
                            }
                        }
                        items(t.length()) { i ->
                            var label = "⚠️ Not ideal"
                            if (good(i)) label = "✅ Good for outdoors"
                            if (i == best && good(i)) label = "⭐ Best day"
                            var rainTxt = "n/a"
                            if (!rain.isNull(i)) rainTxt = "" + rain.getInt(i) + "%"
                            Card(
                                colors = if (i == best && good(i)) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer) else CardDefaults.cardColors(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(LocalDate.parse(t.getString(i)).format(fmt), style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        Text(label, style = MaterialTheme.typography.labelLarge)
                                    }
                                    Text(weatherName(codes.getInt(i)) + " · High " + Math.round(hi.getDouble(i)) + "° / Low " + Math.round(lo.getDouble(i)) + "°C")
                                    Text("Rain chance " + rainTxt + " · Wind up to " + Math.round(wind.getDouble(i)) + " km/h")
                                }
                            }
                        }
                    }
                }
            }
            Text("Weather data by Open-Meteo.com (CC BY 4.0)", style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        }
    }
}
