# Reflection - loading the forecast

**Context**
The main part of my app is the forecast screen. You pick a city and it calls the Open-Meteo forecast api, then shows 7 days and which one is best to go outside. I thought this would be pretty easy, just make the url, get the response, parse the json and show it. My first version just called my getUrl() function straight from the compose code when the screen opened.

**Evidence**
The app crashed right when I tapped a search result. Logcat said android.os.NetworkOnMainThreadException and it was coming from HttpURLConnection.getResponseCode(). After I fixed that I found 2 more problems while testing. First one was if I hit back really fast while the forecast was still loading, the screen would flash my "Couldn't load the forecast" error for a sec even though nothing actually failed. The second one was one city's response had null in the precipitation_probability_max array and my getDouble() threw a JSONException so the whole forecast just didnt load.

**Investigation**
I looked at the android docs and found out you cant do network stuff on the main (UI) thread because it freezes the app and can give you the "App Not Responding" thing. So the request has to go on a background thread and then the result has to come back to the main thread to update the ui. For the error flashing I put a Log.d in my catch (e: Exception) and saw the exception was a CancellationException. When you leave the screen it cancels the LaunchedEffect coroutine and my catch was grabbing that and treating it like the network failed. For the null thing I opened the url in my browser and the json really did have null for some days, so the api doesnt always give a number for everything.

**Decision**
For the threading I thought about using a normal java Thread, or adding Retrofit, or using kotlin coroutines. Coroutines were already in the project from the compose template and LaunchedEffect cancels itself when you leave the screen, which a normal thread wouldnt do (it would keep going and try to update a screen thats gone). So I put the request in withContext(Dispatchers.IO) inside LaunchedEffect. To fix the error flash I added a catch (e: CancellationException) before the normal catch and just rethrow it so only real errors show the error message. For the nulls I check rain.isNull(i) first and show "n/a" if its missing.

**Verification**
- opened a bunch of cities in a row, no more NetworkOnMainThreadException
- pressed back right after tapping a result a bunch of times with slow network on the emulator, no crash and no error flash
- airplane mode, it fails and shows the error + retry button, and retry works when internet is back
- rotated the screen while it was loading and it reloaded fine
- city with null rain values loads and shows n/a

**Reflection**
Next time I would plan every screen that uses the network around loading, success and error from the start instead of adding it after it crashes. I would also look at the real api response before writing the parsing code instead of assuming every field is always there. The main thing I'm taking away is to not trust anything outside my own code, like the network, the api data or the screen lifecycle, and plan for it failing first. I also learned catching every exception can hide stuff like cancellation that isnt actually an error.
