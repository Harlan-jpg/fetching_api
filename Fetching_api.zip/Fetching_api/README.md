# Outdoor Planner

android app that tells you which day this week is best to go outside (hiking, running, biking etc). made with kotlin + jetpack compose

who its for - people who want to go do something outside and dont want to read a whole weather report, just want to know what day is good

## what it does
- search a city (checks the input first so you cant search blank or numbers)
- tap a city -> 7 day forecast w/ weather, high/low, rain chance, wind
- each day gets marked good / not ideal and the best day gets a star
  - "good" = no rain/snow/storm, rain chance 30% or less, high between 10-30C, wind 30km/h or less
- favorites tab, saves places with SharedPreferences so they stay after closing the app
- about tab w/ what the app is + where the data comes from
- loading spinner, empty messages (no results / no favorites), error msg if no internet + retry button on forecast

## API
using Open-Meteo, its free and doesnt need a key

search (geocoding):
`https://geocoding-api.open-meteo.com/v1/search?name={city}&count=10&language=en&format=json`

forecast:
`https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max&timezone=auto&forecast_days=7`

attribution "Weather data by Open-Meteo.com (CC BY 4.0)" is on the screens. requests send a User-Agent header

## setup
1. open the Fetching_api folder in android studio
2. let gradle sync
3. run on emulator or phone (API 35+), needs internet

all the code is in `MainActivity.kt`, theme stuff is in ui/theme

## known limitations
- only celsius and km/h
- cant change what counts as a "good day"
- forecast isnt cached so you need internet to see it (favorites work offline tho)
- search results go away if you rotate the screen
- search only takes letters, spaces, . ' and - (no zip codes)

## demo
1. favorites tab (empty)
2. search blank and "1" -> errors
3. search "zzzzqq" -> no places found
4. search Denver -> loading -> tap it -> forecast
5. save to favorites, close app, reopen, its still there
6. airplane mode -> open forecast -> error -> turn wifi back on -> retry
7. about tab
